/*Test file of Syntax errer: Out of symbol.  But it can go through*/
class Point {
	int z;
	/*Need  ',' before y*/
	int x y ;
	float w;
}
class Test {
	int d;
	/*Need ';' at EOL*/
	Point p = new Point()
	int w,q;
}
