#include <stdio.h>

void main(){
	printf("This is file A\n");
}
