/*
 *	zap_stale does the following
 *	for each stale client found
 *		1) Set abort flag
 *		2) Kill the thread
 *		3) Call disconnect
 */

#include "sms.h"

void zap_stale(void) {	/* call disconnect when needed */

}
