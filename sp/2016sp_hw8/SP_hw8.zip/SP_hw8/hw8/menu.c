/*
 *	menu :
 *	A generalised menu function
 *	The argument is base of an array of Menu_item, which
 *	must be suitably NULL-teminated
 */

#include "sms.h"

void menu(Menu_item *menu) {

}
