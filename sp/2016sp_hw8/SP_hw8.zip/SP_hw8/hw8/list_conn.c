/*
 *	list_conn looks for live connections
 *	It reports the total number and the age of the oldest
 */

#include "sms.h"

void list_conn(void) {	/* list number of current connections */

}
