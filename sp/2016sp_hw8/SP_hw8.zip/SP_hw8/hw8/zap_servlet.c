/*
 *	zap_servlet does the following :
 *		1) Append the message to an appropriate file
 *		2) Capture statistics and push onto stat stack
 *		3) Dispose of the Servlet
 */

#include "sms.h"

void zap_servlet(Servlet *victim) { /* remove and free memeory */
	
}
