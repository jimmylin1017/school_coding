/*
 *	zero_stats just frees the stats stack (means "history")
 */

#include "sms.h"

void zero_stats(void) { /* re-start statistics */

}
