/*
 *	collect_garb :
 *	This function has the following responsibilities :
 *		1) Call zap_servlet
 *		2) Remove the head of the pending tray
 *	collect_garb is activated by the garbage_time semaphore
 */

#include "sms.h"

void *collect_garb(void *info) { /* garbage collector */

	return NULL;
}
